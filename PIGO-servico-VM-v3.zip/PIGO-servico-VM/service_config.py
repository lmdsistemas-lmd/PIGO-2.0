"""Prepare WinSW service files; never installs/starts a Windows service."""
import argparse
import hashlib
import json
import ntpath
from pathlib import Path
import re
import shutil
import subprocess
import xml.etree.ElementTree as ET


WRAPPER_SHA256 = "05b82d46ad331cc16bdc00de5c6332c1ef818df8ceefcd49c726553209b3a0da"


def service_xml(service_id, executable, arguments, working_directory, environment=None):
    if not re.fullmatch(r"Pigo[A-Za-z0-9_-]{1,60}", service_id):
        raise ValueError("Use um ID iniciado por Pigo, somente com letras, numeros, _ ou -.")
    tree = ET.Element("service")
    for name, value in [("id", service_id), ("name", service_id),
                        ("description", "PIGO: execucao independente do terminal e do VS Code."),
                        ("executable", executable), ("arguments", subprocess.list2cmdline(arguments)),
                        ("workingdirectory", working_directory), ("startmode", "Manual"),
                        ("stoptimeout", "30 sec"), ("logpath", r"%BASE%\logs")]:
        ET.SubElement(tree, name).text = str(value)
    account = ET.SubElement(tree, "serviceaccount")
    ET.SubElement(account, "domain").text = "NT AUTHORITY"
    ET.SubElement(account, "user").text = "LocalService"
    for delay in ["10 sec", "30 sec", "60 sec"]:
        ET.SubElement(tree, "onfailure", action="restart", delay=delay)
    log = ET.SubElement(tree, "log", mode="roll-by-size")
    ET.SubElement(log, "sizeThreshold").text = "10240"
    ET.SubElement(log, "keepFiles").text = "5"
    for name, value in (environment or {}).items():
        ET.SubElement(tree, "env", name=name, value=value)
    ET.indent(tree)
    return ET.tostring(tree, encoding="unicode", xml_declaration=True)


def caddy_environment(data_directory, config_directory):
    # Caddy appends 'caddy' to XDG roots. Preserve the currently used directories
    # rather than silently moving certificates when changing the account.
    result = {}
    for name, directory in [("XDG_DATA_HOME", data_directory), ("XDG_CONFIG_HOME", config_directory)]:
        if ntpath.basename(directory.rstrip("\\/")).lower() != "caddy":
            raise ValueError("Confirme os diretorios caddy.AppDataDir/AppConfigDir; caminhos personalizados exigem revisao.")
        result[name] = ntpath.dirname(directory.rstrip("\\/"))
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("role", choices=["api", "caddy"])
    parser.add_argument("--id", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--wrapper", type=Path, required=True)
    parser.add_argument("--app-root", type=Path)
    parser.add_argument("--python", type=Path)
    parser.add_argument("--port", type=int, default=4010)
    parser.add_argument("--caddy-exe", type=Path)
    parser.add_argument("--caddy-config", type=Path)
    parser.add_argument("--caddy-data", type=Path)
    parser.add_argument("--caddy-config-dir", type=Path)
    args = parser.parse_args()
    if not args.wrapper.is_file() or hashlib.sha256(args.wrapper.read_bytes()).hexdigest() != WRAPPER_SHA256:
        parser.error("WinSW diferente do binario oficial fixado nesta entrega.")
    if not 1 <= args.port <= 65535:
        parser.error("Porta invalida.")
    output = args.output.resolve()
    if output.exists():
        parser.error("A pasta de saida deve ser nova; configuracoes existentes nao serao sobrescritas.")
    info = {"id": args.id, "role": args.role, "wrapper_sha256": WRAPPER_SHA256}
    if args.role == "api":
        if not args.app_root or not args.python or not args.python.is_file():
            parser.error("Informe a pasta do PIGO e seu python.exe existente.")
        from run_pigo import configured_environment
        root = args.app_root.resolve()
        backend, _ = configured_environment(root)
        executable = str(args.python.resolve())
        command = [str(output / "run_pigo.py"), "--app-root", str(root), "--port", str(args.port)]
        xml = service_xml(args.id, executable, command, str(backend))
        info.update(app_root=str(root), executable=executable, port=args.port,
                    frontend_entry="explicit-react-routes-v1")
    else:
        paths = [args.caddy_exe, args.caddy_config, args.caddy_data, args.caddy_config_dir]
        if not all(paths) or not args.caddy_exe.is_file() or not args.caddy_config.is_file():
            parser.error("Informe executavel, Caddyfile e diretorios de dados/configuracao existentes do Caddy.")
        if not args.caddy_data.is_dir() or not args.caddy_config_dir.is_dir():
            parser.error("Diretorios atuais de dados/configuracao do Caddy nao encontrados.")
        executable = str(args.caddy_exe.resolve())
        config = str(args.caddy_config.resolve())
        env = caddy_environment(str(args.caddy_data.resolve()), str(args.caddy_config_dir.resolve()))
        xml = service_xml(args.id, executable, ["run", "--config", config, "--adapter", "caddyfile"], str(args.caddy_exe.resolve().parent), env)
        info.update(executable=executable, config=config, data_directory=str(args.caddy_data.resolve()), config_directory=str(args.caddy_config_dir.resolve()))
    output.mkdir(parents=True)
    (output / "logs").mkdir()
    shutil.copy2(args.wrapper, output / (args.id + ".exe"))
    (output / (args.id + ".xml")).write_text(xml, encoding="utf-8")
    (output / "service.json").write_text(json.dumps(info, ensure_ascii=False, indent=2), encoding="utf-8")
    scripts = Path(__file__).resolve().parent
    for name in ["Manage-Service.ps1", "Test-PigoInstance.ps1"]:
        shutil.copy2(scripts / name, output / name)
    if args.role == "api":
        for name in ["run_pigo.py", "frontend_shell.py"]:
            shutil.copy2(scripts / name, output / name)
    print(f"Arquivos preparados em {output}. Servico ainda nao instalado nem iniciado.")


if __name__ == "__main__":
    main()
