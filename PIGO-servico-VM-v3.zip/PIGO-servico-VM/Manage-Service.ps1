#Requires -Version 5.1
[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)][ValidateSet('Install', 'Start', 'Stop', 'EnableAutostart', 'Uninstall', 'Status')][string]$Action
)
$ErrorActionPreference = 'Stop'
if ($env:OS -ne 'Windows_NT') { throw 'Este comando exige Windows Server; nao executa servicos no Linux.' }
$pigoInfo = Get-Content -LiteralPath (Join-Path $PSScriptRoot 'service.json') -Raw | ConvertFrom-Json
if ($pigoInfo.id -notmatch '^Pigo[A-Za-z0-9_-]{1,60}$') { throw 'ID de servico invalido.' }
$pigoWrapper = Join-Path $PSScriptRoot ($pigoInfo.id + '.exe')
$pigoDigest = (Get-FileHash -LiteralPath $pigoWrapper -Algorithm SHA256).Hash.ToLowerInvariant()
if ($pigoDigest -ne '05b82d46ad331cc16bdc00de5c6332c1ef818df8ceefcd49c726553209b3a0da') { throw 'Integridade do WinSW nao confirmada.' }
if ($Action -eq 'Status') { Get-Service -Name $pigoInfo.id; return }
$pigoIdentity = [Security.Principal.WindowsIdentity]::GetCurrent()
$pigoPrincipal = New-Object Security.Principal.WindowsPrincipal($pigoIdentity)
if (-not $pigoPrincipal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) { throw 'Execute este gerenciamento no PowerShell como administrador.' }
function Grant-PigoPath([string]$Path, [string]$Permission) {
    if (-not (Test-Path -LiteralPath $Path)) { throw ('Caminho nao encontrado: ' + $Path) }
    $pigoResolvedPath = (Resolve-Path -LiteralPath $Path).Path
    if ($pigoResolvedPath.TrimEnd('\') -eq [IO.Path]::GetPathRoot($pigoResolvedPath).TrimEnd('\')) { throw 'Use uma pasta dedicada; permissoes na raiz do disco nao serao alteradas.' }
    $pigoGrant = '*S-1-5-19:' + $Permission
    & icacls.exe $Path /grant $pigoGrant | Out-Null
    if ($LASTEXITCODE -ne 0) { throw ('Falha ao conceder acesso LocalService: ' + $Path) }
}
switch ($Action) {
    'Install' {
        if (Get-Service -Name $pigoInfo.id -ErrorAction SilentlyContinue) { throw 'Servico ja existente; nao sera substituido.' }
        Grant-PigoPath $PSScriptRoot '(OI)(CI)RX'
        Grant-PigoPath (Join-Path $PSScriptRoot 'logs') '(OI)(CI)M'
        if ($pigoInfo.role -eq 'api') {
            & $pigoInfo.executable (Join-Path $PSScriptRoot 'run_pigo.py') --app-root $pigoInfo.app_root --port $pigoInfo.port --check
            if ($LASTEXITCODE -ne 0) { throw 'Configuracao do PIGO incompleta; servico nao instalado.' }
            Grant-PigoPath $pigoInfo.app_root '(OI)(CI)RX'
            Grant-PigoPath $pigoInfo.executable 'RX'
            $pigoBasePython = & $pigoInfo.executable -c 'import sys; print(sys.base_prefix)'
            if ($LASTEXITCODE -ne 0) { throw 'Nao foi possivel identificar o runtime Python.' }
            Grant-PigoPath (([string]$pigoBasePython).Trim()) '(OI)(CI)RX'
        } else {
            Grant-PigoPath (Split-Path -Parent $pigoInfo.executable) '(OI)(CI)RX'
            Grant-PigoPath (Split-Path -Parent $pigoInfo.config) '(OI)(CI)RX'
            Grant-PigoPath $pigoInfo.data_directory '(OI)(CI)M'
            Grant-PigoPath $pigoInfo.config_directory '(OI)(CI)M'
        }
        & $pigoWrapper install
        if ($LASTEXITCODE -ne 0) { throw 'WinSW nao instalou o servico.' }
        Write-Output 'Servico instalado em modo manual, ainda sem iniciar.'
    }
    'Start' {
        if ((Get-Service -Name $pigoInfo.id).Status -eq 'Running') { Write-Output 'Servico ja em execucao.'; return }
        if ($pigoInfo.role -eq 'api') {
            if (Get-NetTCPConnection -State Listen -LocalPort $pigoInfo.port -ErrorAction SilentlyContinue) { throw 'Porta ocupada. O processo atual nao sera encerrado automaticamente.' }
        } elseif (Get-Process -Name caddy -ErrorAction SilentlyContinue) { throw 'O Caddy atual ainda esta aberto. Encerre-o manualmente somente na troca planejada.' }
        & $pigoWrapper start
        if ($LASTEXITCODE -ne 0) { throw 'Falha ao iniciar o servico; consulte a pasta logs.' }
        if ($pigoInfo.role -eq 'api') {
            $pigoOk = $false
            for ($pigoAttempt = 0; $pigoAttempt -lt 20; $pigoAttempt++) {
                try { $pigoResult = Invoke-RestMethod -Uri ('http://127.0.0.1:' + $pigoInfo.port + '/api/health') -TimeoutSec 2; if ($pigoResult.status -eq 'ok') { $pigoOk = $true; break } } catch { }
                Start-Sleep -Milliseconds 500
            }
            if (-not $pigoOk) { Stop-Service -Name $pigoInfo.id; throw 'API nao ficou pronta; servico interrompido. Consulte logs.' }
            try { & (Join-Path $PSScriptRoot 'Test-PigoInstance.ps1') -Port $pigoInfo.port }
            catch { Stop-Service -Name $pigoInfo.id; throw }
        }
        Get-Service -Name $pigoInfo.id
    }
    'Stop' { Stop-Service -Name $pigoInfo.id }
    'EnableAutostart' {
        if ((Get-Service -Name $pigoInfo.id).Status -ne 'Running') { throw 'Valide o servico iniciado antes de habilitar inicio automatico.' }
        if ($pigoInfo.role -eq 'api') { & (Join-Path $PSScriptRoot 'Test-PigoInstance.ps1') -Port $pigoInfo.port }
        & sc.exe config $pigoInfo.id 'start=' 'delayed-auto'
        if ($LASTEXITCODE -ne 0) { throw 'Falha ao configurar inicializacao automatica.' }
        Write-Output 'Inicio automatico com atraso habilitado; confirme tambem apos reiniciar o servidor.'
    }
    'Uninstall' {
        if ((Get-Service -Name $pigoInfo.id).Status -ne 'Stopped') { throw 'Pare o servico antes de remove-lo.' }
        & $pigoWrapper uninstall
        if ($LASTEXITCODE -ne 0) { throw 'WinSW nao removeu o servico.' }
        Write-Output 'Servico removido. Aplicacao, configuracao, certificados, logs e bancos preservados.'
    }
}
