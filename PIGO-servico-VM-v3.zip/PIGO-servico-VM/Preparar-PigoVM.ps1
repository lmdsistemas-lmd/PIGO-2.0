#Requires -Version 5.1
[CmdletBinding()]
param()
$ErrorActionPreference = 'Stop'
if ($env:OS -ne 'Windows_NT' -or $env:COMPUTERNAME -ne 'WIN-JG1E0O7FSBS') {
    throw 'Execute somente na VM WIN-JG1E0O7FSBS.'
}
$pigoAppRoot = 'C:\Projetos\P.I.G.O'
$pigoPython = Join-Path $pigoAppRoot 'backend\venv\Scripts\python.exe'
$pigoOutput = 'C:\ProgramData\PIGO Services\PigoDashboardTest'
if (Get-Service -Name 'PigoDashboardTest' -ErrorAction SilentlyContinue) {
    throw 'O servico PigoDashboardTest ja existe; nao sera substituido.'
}
if (Test-Path -LiteralPath $pigoOutput) {
    throw 'A pasta PigoDashboardTest ja existe. Preserve-a e informe o retorno antes de repetir a preparacao.'
}
if (-not (Test-Path -LiteralPath $pigoPython -PathType Leaf)) {
    throw 'Python do backend nao encontrado nesta VM.'
}
Write-Output 'Conferindo a instancia temporaria atual em 127.0.0.1:4010...'
try {
    & (Join-Path $PSScriptRoot 'Test-PigoInstance.ps1') -Port 4010
} catch {
    throw ('A instancia atual ainda nao passou na verificacao: ' + $_.Exception.Message + ' Nenhum servico foi instalado. Mantenha o terminal 4010 aberto para diagnostico.')
}
& (Join-Path $PSScriptRoot 'Prepare-PigoService.ps1') `
    -AppRoot $pigoAppRoot -PythonPath $pigoPython `
    -OutputDirectory $pigoOutput -ServiceId 'PigoDashboardTest' -Port 4010
Write-Output 'Preparacao concluida; nenhum servico instalado ou iniciado.'
Write-Output ('Arquivos: ' + $pigoOutput)
