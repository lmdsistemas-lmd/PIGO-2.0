#Requires -Version 5.1
[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)][string]$AppRoot,
    [Parameter(Mandatory = $true)][string]$OutputDirectory,
    [string]$PythonPath,
    [string]$WrapperPath = (Join-Path $PSScriptRoot 'tools\WinSW-x64-2.12.0.exe'),
    [ValidatePattern('^Pigo[A-Za-z0-9_-]{1,60}$')][string]$ServiceId = 'PigoDashboardTest',
    [ValidateRange(1,65535)][int]$Port = 4010
)
$ErrorActionPreference = 'Stop'
if ($env:OS -ne 'Windows_NT') { throw 'Execute a preparacao no Windows Server.' }
$pigoRoot = (Resolve-Path -LiteralPath $AppRoot).Path
if (-not $PythonPath) {
    $pigoCandidates = @('backend\venv\Scripts\python.exe', 'backend\.venv\Scripts\python.exe', '.venv\Scripts\python.exe')
    foreach ($pigoRelative in $pigoCandidates) {
        $pigoCandidate = Join-Path $pigoRoot $pigoRelative
        if (Test-Path -LiteralPath $pigoCandidate -PathType Leaf) { $PythonPath = $pigoCandidate; break }
    }
}
if (-not $PythonPath -or -not (Test-Path -LiteralPath $PythonPath -PathType Leaf)) { throw 'Informe -PythonPath com o python.exe do backend desta VM.' }
& $PythonPath (Join-Path $PSScriptRoot 'run_pigo.py') --app-root $pigoRoot --port $Port --check
if ($LASTEXITCODE -ne 0) { throw 'Pre-verificacao falhou; nenhum servico foi instalado.' }
& $PythonPath (Join-Path $PSScriptRoot 'service_config.py') api --id $ServiceId --app-root $pigoRoot --python $PythonPath --port $Port --output $OutputDirectory --wrapper $WrapperPath
if ($LASTEXITCODE -ne 0) { throw 'Nao foi possivel preparar os arquivos do servico.' }
