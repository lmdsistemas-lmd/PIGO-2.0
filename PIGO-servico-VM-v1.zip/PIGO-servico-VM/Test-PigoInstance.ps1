#Requires -Version 5.1
[CmdletBinding()]
param([ValidateRange(1, 65535)][int]$Port = 4010)
$ErrorActionPreference = 'Stop'
$pigoBaseUrl = 'http://127.0.0.1:' + $Port
$pigoHealth = Invoke-RestMethod -Uri ($pigoBaseUrl + '/api/health') -TimeoutSec 15
if ($pigoHealth.status -ne 'ok' -or $pigoHealth.service -ne 'pigo') {
    throw 'A porta nao respondeu como API do PIGO.'
}
foreach ($pigoRoute in @('/login', '/dashboard/vendas', '/funcionarios', '/performance', '/cadastros/produtos')) {
    $pigoResponse = Invoke-WebRequest -UseBasicParsing -Uri ($pigoBaseUrl + $pigoRoute) -Headers @{ Accept = 'text/html' } -TimeoutSec 15
    if ($pigoResponse.StatusCode -ne 200 -or $pigoResponse.Headers['Content-Type'] -notmatch 'text/html') {
        throw ('Painel compilado nao disponivel em ' + $pigoRoute)
    }
}
$pigoRejected = $false
try {
    $null = Invoke-WebRequest -UseBasicParsing -Uri ($pigoBaseUrl + '/api/me/tenant') -TimeoutSec 15
} catch {
    if ($_.Exception.Response -and [int]$_.Exception.Response.StatusCode -eq 401) { $pigoRejected = $true }
    else { throw }
}
if (-not $pigoRejected) { throw 'A consulta protegida deveria exigir autenticacao.' }
Write-Output 'API, painel compilado, acesso direto as telas e autenticacao verificados. Nenhuma gravacao enviada.'
